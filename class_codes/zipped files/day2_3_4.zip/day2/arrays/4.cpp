#include<iostream>
#include<string>
#include<stdio.h>


int main()
{
  int arr[5] {11, 22, 33, 44, 55};
  int brr[5] {10, 20, 30, 40, 50};
  std::cout << "arr[7] = " << arr[7] << std::endl;
  std::cout << "brr[7] = " << brr[7] << std::endl;
  std::cout << "arr[10] = " << arr[10] << std::endl;
  std::cout << "brr[10] = " << brr[10] << std::endl;
  return 0;

}
