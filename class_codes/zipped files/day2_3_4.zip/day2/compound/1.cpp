#include<iostream>

int main()
{
//  auto varx {12/4};
//  auto vary {12.0/3};

  // l value
  int varx {10};      // 10 r value
  int vary {varx};    // x is an lvalue expression

  // mov 30 #60
  // mov 40 50

  return 0;
}
