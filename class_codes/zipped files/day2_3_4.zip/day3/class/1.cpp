#include<iostream>

class Sample
{
public:
  Sample()
  {
    //code to perform task A
  }
  Sample(int val):Sample{} //use Sample()
  {
    // code to preform taskB
  }
};
