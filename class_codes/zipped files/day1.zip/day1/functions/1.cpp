#include<iostream>
// prototype
// declaration
// forward declaration
int add(int la , int lb);

int main()
{
	int ma {};
	ma = add(100, 200);
	return 0;
}

// code
// definition 
int add(int la, int lb)
{
	return la + lb;
}
