#include<iostream>

int main(){
	int varx = 30;
	int vary {13};
	}
